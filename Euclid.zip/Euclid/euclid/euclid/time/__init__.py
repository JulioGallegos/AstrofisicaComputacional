"""
Time submodule
"""
