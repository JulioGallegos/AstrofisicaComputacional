"""
Euclid - Python tutorial project

The purpose of this toy-model project is to show the various possibilities
to organized.


"""
from . import maths
from .time.mytime import now
