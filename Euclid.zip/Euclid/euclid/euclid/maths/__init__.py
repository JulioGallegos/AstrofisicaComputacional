"""
Maths submodule

Contains
- trigonometric methods
- stats methods

"""
from .mytrigo import *
from .mystats import average
