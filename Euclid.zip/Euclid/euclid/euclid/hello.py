#!/usr/bin/env python3
# -*- coding: utf-8 -*-


def helloworld():
    """
    Hello world routine !
    """
    print("Hello world!")
